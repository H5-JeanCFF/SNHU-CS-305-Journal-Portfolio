package com.twk.restservice;
 

public class myDateTime {
	int mySecond;
	int myMinute;
	int myHour;
	
	int[] retrieveDateTime() {
		/* implement accessor method */
		return new int[3];
	}
	
	void setMyDateTime(int seconds, int minutes, int hour) {
		/* implement accessor method */
	}
	

}
